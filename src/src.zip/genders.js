module.exports = {
	"GENDERS" : {
		"male" 	 : "male",
		"female" : "female"
	}
};
